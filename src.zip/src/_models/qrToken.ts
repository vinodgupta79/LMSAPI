export interface QrToken {
    qrToken: string;
    userId: string;
    isUsed: number;
    usedAt: string;
    isActive: number;
}