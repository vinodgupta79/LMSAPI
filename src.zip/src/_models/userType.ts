export default class UserType {
    public id?: number;
    public userType?: string;
    public remark?: string;

    public UserType() {
        this.id = 0,
            this.userType = '',
            this.remark = ''
    }
}
